const express=require('express');
const app=express();
const fs=require("fs");

var user4={
	"user4" :{
    "name":"ankit",
    "password":"password4",
    "profession":"student",
    "id":4
     }
}
app.get('/addUsers',function(req,res){
	fs.readFile(__dirname+"/"+"user.json",'utf8',function(err,data){
		data=JSON.parse(data);
		data["user4"]=user["user4"];
		console.log(data);
		res.end(data);
	});
});

const server=app.listen(8080,function(){
	const host=server.address().address
	const port=server.address().port
	console.log("Example app listening at http://%s:%s0",host,port)
})