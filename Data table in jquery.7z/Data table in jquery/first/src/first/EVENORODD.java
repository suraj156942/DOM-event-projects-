package first;
import java.util.Scanner;
public class EVENORODD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int n;
         Scanner sc=new Scanner(System.in);
         System.out.println("Enter a number");
         n=sc.nextInt();
         sc.close();
         if(n/2==0) 
         {
        	 System.out.println("Enter number"+n+"is even");
         }
         else
         {
        	 System.out.println("Enter number"+n+"is odd");
         }
	}

}
