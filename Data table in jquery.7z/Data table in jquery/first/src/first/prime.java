    

    //prime number between 1 to 100
package first;

public class prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no,j;
	   System.out.println("the prime number between 1 to 100");
	   for(no=1;no<=100;no++)
	   {
		   for(j=2;j<=no/2;j++)
		   {
			    if(no%j==0)
			    	break;
		   }
		     if(j>no/2)
		    	 System.out.println(" "+no);
		   
	   }

	}

}
