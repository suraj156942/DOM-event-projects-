package first;
import java.util.Scanner;

public class characterInput {

	public static void main(String[] args) {
		char c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a character");
		c=sc.next().charAt(0);
		sc.close();
		System.out.println("you entered "+c);

	}

}
