package first;
import java.util.Scanner;
public class ARM {

	public static void main(String[] args) {
	  int n1,n,r,s=0;
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter a number");
	  n=sc.nextInt();
	  sc.close();
	  n1=n;
	  while(n>0)
	  {
		  r=n%10;
		  s=s+r*r*r;
		  n=n/10;
	 }
	  if(n1==s)
	  {
		  System.out.println("Enter number is Armstrong");
	  }
	  else
	  {
		  System.out.println("Enter number is not Armstrong");
	  }
		
	}

}
