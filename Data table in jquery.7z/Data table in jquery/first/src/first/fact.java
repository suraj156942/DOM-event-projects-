package first;
import java.util.Scanner;
public class fact {

	public static void main(String[] args) {
       int n,i,f=1;
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter a number");
       n=sc.nextInt();
       sc.close();
       for(i=1;i<=n;i++)
       {
    	   f=f*i;
       }
     System.out.println("Factorial " +n+ " is="+f);
	}

}
