package first;
import java.lang.Math;
public class random {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       System.out.println("random number "+ Math.random());
	}

}