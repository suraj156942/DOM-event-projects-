package first;
import java.util.Scanner;
public class swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two number");
		a=sc.nextInt();
		b=sc.nextInt();
		sc.close();
		
		c=a;
		a=b;
		b=c;
		System.out.println("After swapping the value is "+a+" " +b);

	}

}
